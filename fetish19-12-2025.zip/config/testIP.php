<?php

// return [
//     'IT' => 'it',
//     'DE' => 'de',
//     'FR' => 'fr',
//     'ES' => 'es',
//     'RU' => 'ru',
//     'CN' => 'zh',
//     'JP' => 'jp',
//     'PT' => 'pt',
//     'PL' => 'pl',
//     'TR' => 'tr',
//     'US' => 'en',
//     'GB' => 'en',
//     'CA' => 'en',
//     'AU' => 'en',
// ];

return [
    'IT' => '2.44.20.1',    // Italy
    'DE' => '91.12.45.33',  // Germany
    'FR' => '82.64.120.77', // France
    'ES' => '85.48.23.99',  // Spain
    'RU' => '95.24.15.1',   // Russia
    'CN' => '36.112.0.1',   // China
    'JP' => '133.18.200.1', // Japan
    'PT' => '188.250.12.1', // Portugal
    'PL' => '83.24.199.1',  // Poland
    'TR' => '88.240.129.1', // Turkey
    //'US' => '8.8.8.8',      // USA
];
