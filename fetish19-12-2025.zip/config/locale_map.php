<?php

return [
    'IT' => 'it',
    'DE' => 'de',
    'FR' => 'fr',
    'ES' => 'es',
    'RU' => 'ru',
    'CN' => 'zh',
    'JP' => 'jp',
    'PT' => 'pt',
    'PL' => 'pl',
    'TR' => 'tr',
    'US' => 'en',
    'GB' => 'en',
    'CA' => 'en',
    'AU' => 'en',
];

