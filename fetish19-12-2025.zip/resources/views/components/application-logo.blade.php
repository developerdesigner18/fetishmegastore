<img src="{{ asset(opt('site_logo')) }}" alt="logo" class="h-16 mr-2" />
