import { usePage } from "@inertiajs/inertia-react";
import React from "react";

export default function BottomAdBlock() {
    return (
        <>
            <div
                style={{marginTop: '5px'}}
                className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-3 gap-5">
                <div
                    className="border dark:border-zinc-800 shadow-sm rounded-lg pb-2 bg-white dark:bg-zinc-900"
                >
                    <div className="relative">
                        <p>
                            <a title="She is bound to be passionate!"
                               href="https://ctjdwm.com/?siteId=wl3&amp;cobrandId=244314&amp;superCategoryName=[--SUPERCATEGORY--]&amp;categoryName=girls/fetish&amp;pageName=listpage&amp;prm[psid]=6camgirl&amp;prm[pstool]=211_17&amp;prm[psprogram]=cbrnd&amp;prm[campaign_id]=&amp;subAffId={SUBAFFID}"
                               target="_blank" rel="noopener">
                                <img style={{width: '100%', height: '100%'}}
                                     title="She is bound to be passionate!"
                                     src="https://pt-static1.ptwmstcnt.com/npt/banner/gif/fetish_1/300xx250.gif?sid=3748e0e8&amp;psid=6camgirl&amp;pstool=211_17&amp;psprogram=cbrnd&amp;campaign_id="
                                     alt="She is bound to be passionate!"/>
                            </a>
                        </p>
                    </div>
                </div>

                <div
                    className="border dark:border-zinc-800 shadow-sm rounded-lg pb-2 bg-white dark:bg-zinc-900"
                >
                    <div className="relative">
                        <p><a title="Live Fetish sex!"
                              href="https://ctjdwm.com/?siteId=wl3&amp;cobrandId=244314&amp;superCategoryName=girls&amp;categoryName=fetish&amp;pageName=listpage&amp;prm[psid]=6camgirl&amp;prm[pstool]=201_7&amp;prm[psprogram]=cbrnd&amp;prm[campaign_id]=&amp;subAffId={SUBAFFID}"
                              target="_blank" rel="noopener">
                            <img class="img    "
                                 style={{width: '100%', height: '100%'}}
                                 title="Live Fetish sex!"
                                 src="https://pt-static1.ptwmstcnt.com/npt/banner/s1_fetish/300xx250.jpg?sid=a8710fe7&amp;psid=6camgirl&amp;pstool=201_7&amp;psprogram=cbrnd&amp;campaign_id="
                                 srcset="" alt="Live Fetish sex!"/> </a></p>
                    </div>
                </div>

                <div
                    className="border dark:border-zinc-800 shadow-sm rounded-lg pb-2 bg-white dark:bg-zinc-900"
                >
                    <div className="relative">
                        <p>
                            <a href="https://adult-clips.eu/">
                                <img
                                    class="  wizmage-pattern-bg-img wizmage-cls wizmage-shade-2"
                                    style={{height: '100%'}} title="PornMayer.com"
                                    src="https://www.footgirls.at/image/adultclips330x250.JPG" srcset=""
                                    alt="PornMayer.com"/> </a>
                        </p>
                    </div>
                </div>
            </div>
        </>
    );
}
