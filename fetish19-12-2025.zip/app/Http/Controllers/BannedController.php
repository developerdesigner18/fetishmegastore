<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BannedController extends Controller
{
    //
    public function banned()
    {
        return redirect('https://google.com');
    }
}
