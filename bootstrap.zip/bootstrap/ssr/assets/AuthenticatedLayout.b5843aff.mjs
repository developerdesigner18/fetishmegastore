import "react";
import { F as Front } from "./Front.602cce17.mjs";
import { a as jsx } from "../app.mjs";
function Authenticated({
  auth,
  children
}) {
  return /* @__PURE__ */ jsx(Front, {
    children
  });
}
export {
  Authenticated as A
};
