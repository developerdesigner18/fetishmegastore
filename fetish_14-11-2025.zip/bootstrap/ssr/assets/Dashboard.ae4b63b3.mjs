import Navi from "./Navi.ed028ffd.mjs";
import { j as jsxs, F as Fragment, a as jsx } from "../app.mjs";
import "@inertiajs/inertia-react";
import "lodash";
import "axios";
import "laravel-echo";
import "pusher-js";
import "react";
import "react-dom/client";
import "@inertiajs/progress";
import "react/jsx-runtime";
function Dashboard() {
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx(Navi, {}), '"Dashboard... from component"']
  });
}
export {
  Dashboard as default
};
