 <th
     class="
                    p-3
                    font-semibold
                    uppercase
                    bg-gray-200
                    text-gray-600
                    border border-gray-300
                    hidden
                    lg:table-cell
                ">
     {{ $slot }}
 </th>
