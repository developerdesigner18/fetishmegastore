<div class="proceed-to-pay">
    <div class="pay-section">
        <div class="flex justify-center items-center">
            <div class="mr-2">
            </div>
            <div>
                <h3 class="text-3xl font-semibold dark:text-white text-center">
                    {{ __('PayPal') }}
                </h3>
            </div>
        </div>
    </div>
</div>